//
//  MainViewController.swift
//  Michaelsoft Phaint V9
//
//  Created by Paul V Krebs on 4/22/23.
//

import UIKit
import AVKit
import PhotosUI


class MainViewController: UIViewController, PHPickerViewControllerDelegate{
    
//    var inputImage: UIImage = canvas as! UIImage
    let userDefaults = UserDefaults.standard
    var aNewView: UIView?
    static var drawSize: Float = 0.5
    static var colorWellColor: UIColor = .blue
    static var drawMode: Bool = false
    var assetButton1OutletY: CGFloat = 0.0
    var photoButtonOutletY: CGFloat = 0.0
    var picker: PHPickerViewController?
    var offset: CGPoint = CGPointMake(0, 0)
    var topCanvas: Canvas?
    @IBOutlet weak var photoButtonOutlet: UIButton!
    @IBOutlet weak var assetButton1Outlet: UIButton!
    
    @IBOutlet weak var drawModeButtonOutlet: UIButton!
    @IBOutlet weak var drawSlider: UISlider!
    
    @IBAction func drawSliderAction(_ sender: Any) {
        userDefaults.set(drawSlider.value, forKey: "sliderVal")
        MainViewController.drawSize = drawSlider.value
    }
    @IBOutlet var pinchGR: UIPinchGestureRecognizer!
    
    @IBAction func DrawModeButton(_ sender: Any) {
//        userDefaults.set(myColorWell.selectedColor, forKey: "color")
        MainViewController.drawMode = !MainViewController.drawMode
        if MainViewController.drawMode {
            drawModeButtonOutlet.setTitle("Drawmode\nActivated", for: .normal)
           
            assetButton1OutletY = assetButton1Outlet.center.y
            photoButtonOutletY = photoButtonOutlet.center.y
            UIView.animate(withDuration: 1.2, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0.0, animations: {
                
                self.assetButton1Outlet.center.y = self.assetButton1OutletY - 150
                self.photoButtonOutlet.center.y = self.photoButtonOutletY - 150
                self.drawSlider.center.y = self.assetButton1OutletY
            })
            let view = Canvas(frame: canvas.bounds)
            view.backgroundColor = .clear
            canvas.addSubview(view)
            topCanvas = view
        }
        else{
            drawModeButtonOutlet.setTitle("Drawmode\nOff", for: .normal)
            UIView.animate(withDuration: 1.2, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0.0, animations: {
                self.photoButtonOutlet.center.y = self.photoButtonOutletY
                self.assetButton1Outlet.center.y = self.assetButton1OutletY
                self.drawSlider.center.y = self.assetButton1OutletY - 150
            })
        }
    }
    
    
    class ImageSaver: NSObject {
        func writeToPhotoAlbum(image: UIImage) {
            UIImageWriteToSavedPhotosAlbum(image, self, #selector(saveCompleted), nil)
        }

        @objc func saveCompleted(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
            print("Save finished!")
        }
    }
    
    
    @IBAction func photoExport(_ sender: Any) {
        print("here1")
        let renderer = UIGraphicsImageRenderer(size: canvas.frame.size)
        let image = renderer.image { ctx in
            canvas.drawHierarchy(in: canvas.bounds, afterScreenUpdates: false)
        }
        let inputImage = image //else { return }

        let imageSaver = ImageSaver()
        imageSaver.writeToPhotoAlbum(image: inputImage)
        
        let alert = UIAlertController(title: "Exported", message: "Thanks for exporting", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Aight", style: .default, handler: nil))
        
        
        self.present(alert, animated: true, completion: nil)
    }
    
    
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]){
        if let itemProvider = results.first?.itemProvider, itemProvider.canLoadObject(ofClass: UIImage.self){
            itemProvider.loadObject(ofClass: UIImage.self){image, error in
                if let image = image as? UIImage {
                    DispatchQueue.main.async { [self] in
                        print("hi")
//                        let newView = UserView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
                        let myImage = UIImageView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
                        myImage.image = image
                        myImage.isUserInteractionEnabled = true
                        self.canvas.addSubview(myImage)
                        self.canvas.bringSubviewToFront(myImage)
                        aNewView = myImage
                        addGesture()
                    }
                }
            }
        }
        self.picker?.dismiss(animated: true)
    }
    
    
        
        
    
    @IBAction func PhotoButton(_ sender: Any) {
        
//        let status = PHPhotoLibrary.authorizationStatus(for: .readWrite)
//
//        if status != .authorized && status != .limited{
//            PHPhotoLibrary.requestAuthorization(for: .readWrite) { status in print("Status = \(status)")}
//        }
        
        let config = PHPickerConfiguration(photoLibrary: .shared())
        //do other config
        picker = PHPickerViewController(configuration: config)
        if let picker = picker{
            picker.delegate = self
            present(picker, animated: true)
        }

    }
    
    
    @IBOutlet weak var myColorWell: UIColorWell!
    var myImage: UserImage?
    var hasColorBeenUsed = false;
//    var picker: PHPickerViewController?
    
    var movingObject: UIView?
    var scaleObject: UIView?
    @IBOutlet weak var canvas: UIView!
    
    @IBAction func AssetButton1(_ sender: Any) {
        print("button")
        let newView = UserView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
//        newView.addTarget(pinchGR)
        func pinch2(_ sender: UIPinchGestureRecognizer) {guard sender.view != nil else { return }
            //print(movingObject?.backgroundColor)
            if sender.state == .began || sender.state == .changed {
                sender.view?.transform = (sender.view?.transform.scaledBy(x: sender.scale, y: sender.scale))!
                sender.scale = 1.0
            }}
        
        let center = newView.center
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.1, initialSpringVelocity: 0.1, animations: {
//            self.aniView.center.x += 50
//            self.aniView.center.y += 25
            newView.center.x = newView.center.x - 10
            newView.center.y = newView.center.y + 10
//                        var myTransformation = piece.transform.rotated(by: 16)
            newView.layer.transform = CATransform3DMakeRotation(0.06, 0, 0, 0.5)
//                        piece.backgroundColor = .red
        }, completion: {_ in
            UIView.animate(withDuration: 0.3, delay: 0.1, usingSpringWithDamping: 0.4, initialSpringVelocity: 0.2, options: .curveEaseIn, animations: {
                if abs(newView.center.x - center.x) < 50 && abs( newView.center.y - center.y) < 50{
                    newView.center = center
                }
                newView.layer.transform = CATransform3DMakeRotation(0, 0, 0, 0)
            })
        })
        
        
        
//            print(myColorWell.selectedColor)
            
        
        
        if (myColorWell.selectedColor != nil){
            newView.backgroundColor = myColorWell.selectedColor
        }else{
            newView.backgroundColor = .orange
        }
        
        canvas.addSubview(newView)
        canvas.bringSubviewToFront(newView)
        aNewView = newView
        aNewView?.autoresizesSubviews = true
        addGesture()
        
        
    }
    
    private func addGesture() {
        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(pinch(_ :)))
        
        let rotateGesture = UIRotationGestureRecognizer(target: self, action: #selector(rotatePiece(_ :)))
        
        aNewView!.addGestureRecognizer(pinchGesture)
        aNewView!.addGestureRecognizer(rotateGesture)
    }
    
    var pinchSize: CGFloat = 100
    
    @objc private func rotatePiece(_ gestureRecognizer : UIRotationGestureRecognizer) {   // Move the anchor point of the view's layer to the center of a
       // person's two fingers. This creates a more natural looking rotation.
       guard gestureRecognizer.view != nil else { return }
            
       if gestureRecognizer.state == .began || gestureRecognizer.state == .changed {
          gestureRecognizer.view?.transform = gestureRecognizer.view!.transform.rotated(by: gestureRecognizer.rotation)
          gestureRecognizer.rotation = 0
       }}
    
    @objc private func pinch(_ sender: UIPinchGestureRecognizer) {
        print("in")
        //print(movingObject?.backgroundColor)
        if sender.state == .changed {
//            movingObject!.transform = (movingObject!.transform.scaledBy(x: sender.scale, y: sender.scale))
//            sender.scale = 1.0
            
            let scale = sender.scale
//            let frame = movingObject!.frame
            let myCenter = movingObject!.center
            print("subviews")
//            var subview = movingObject!.subviews.first
            print(movingObject!.subviews.count)
            movingObject!.bounds = CGRect(x: 0, y: 0, width: pinchSize * scale * 1.5, height: pinchSize * scale * 1.5)
            
            movingObject!.center = myCenter
            
//            debugPrint("subview ", movingObject!.subviews.first?.bounds)
            movingObject!.setNeedsDisplay()
        }
        
    }
    
    func bad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
        let status = PHPhotoLibrary.authorizationStatus(for: .readWrite)
        
        if status != .authorized && status != .limited{
            PHPhotoLibrary.requestAuthorization(for: .readWrite) { status in print("Status = \(status)")}
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        topCanvas = canvas as? Canvas
        drawSlider.center.y = photoButtonOutlet.center.y - 150

//         Do any additional setup after loading the view.
        let status = PHPhotoLibrary.authorizationStatus(for: .readWrite)

        if status != .authorized && status != .limited{
            PHPhotoLibrary.requestAuthorization(for: .readWrite) { status in print("Status = \(status)")}
        }
        
        drawSlider.value = userDefaults.float(forKey: "sliderVal")
        MainViewController.drawSize = userDefaults.float(forKey: "sliderVal")
//        userDefaults.set(<#T##value: Any?##Any?#>, forKey: <#T##String#>)
        
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("here")
        if touches.count == 1 {
            if(MainViewController.drawMode){
                let drawingColour = myColorWell.selectedColor ?? .blue
                MainViewController.colorWellColor = myColorWell.selectedColor ?? .blue
                guard let touch = touches.first else {return}
                let firstPoint = touch.location(in: canvas)
                if let topCanvas = topCanvas {
                    topCanvas.colourArray.append(drawingColour.cgColor)
                    topCanvas.drawSizeArray.append(CGFloat(drawSlider.value) * 100)
                    topCanvas.lineArray.append([CGPoint]())
                    topCanvas.lineArray[topCanvas.lineArray.count - 1].append(firstPoint)
                }
            }
            else{
                var reverseTransform: CATransform3D?
                if let piece = canvas.hitTest((touches.first?.location(in: canvas))!, with: event) {
                    if piece == canvas {
                        debugPrint("Found the Canvas")
                        movingObject = canvas
                        let touchPoint = touches.first!.location(in: self.view)
                        offset.x = touchPoint.x - piece.center.x
                        offset.y = touchPoint.y - piece.center.y
                        debugPrint("Offset = \(offset)")
                    } else {
                        debugPrint("Found something else")
                        movingObject = piece
                        let touchPoint = touches.first!.location(in: canvas)
                        offset.x = touchPoint.x - piece.center.x
                        offset.y = touchPoint.y - piece.center.y
                        
                        let background = piece.backgroundColor
                        let center = piece.center
                        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.1, initialSpringVelocity: 0.1, animations: {
                            //            self.aniView.center.x += 50
                            //            self.aniView.center.y += 25
//                            piece.draw(piece.bounds)
                            piece.center.x = piece.center.x - 10
                            piece.center.y = piece.center.y + 10
                            //                        var myTransformation = piece.transform.rotated(by: 16)
                            reverseTransform = piece.layer.transform
                            piece.layer.transform = CATransform3DMakeRotation(0.06, 0, 0, 0.5 + piece.layer.zPosition)
                            
                            //                        piece.backgroundColor = .red
                        }, completion: {_ in
                            UIView.animate(withDuration: 0.3, delay: 0.1, usingSpringWithDamping: 0.4, initialSpringVelocity: 0.2, options: .curveEaseIn, animations: {
                                if abs(piece.center.x - center.x) < 50 && abs( piece.center.y - center.y) < 50{
                                    piece.center = center
                                }
//                                piece.layer.transform = CATransform3DMakeRotation(0, 0, 0, 0)
                                piece.layer.transform = reverseTransform!
                                piece.backgroundColor = background
                            })
                        })
                    }
                }
            }
        }
        if touches.count == 2{
            debugPrint("There are 2")
        }
        
       
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        //todo: make work
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if touches.count == 1 {
            if MainViewController.drawMode{
                guard let touch = touches.first else {return}
                let currentPoint = touch.location(in: canvas
                )
                if let topCanvas = topCanvas {
                    topCanvas.lineArray[topCanvas.lineArray.count - 1].append(currentPoint)
                    
    //                setNeedsDisplay()
                    topCanvas.setNeedsDisplay()
                }
            }
            else{
                if let movingObject = movingObject {
                    if(movingObject != canvas){
                        movingObject.center = touches.first!.location(in: canvas)
                        canvas.bringSubviewToFront(movingObject)
                        
                        if canvas.frame.contains(touches.first!.location(in: self.view))  {
                            var newPoint = touches.first!.location(in: canvas)
                            debugPrint("newPoint =  \(newPoint)")
                            newPoint.x -= offset.x
                            newPoint.y -= offset.y
                            debugPrint("Modified =  \(newPoint)")
                            //movingObject. = touches.first!.location(in: self.view)
                            
                            movingObject.center = newPoint
                        }
                        
                    }else{
                        //                    Get point in canvas
                        
                        //                    calculate the offset from canvas centre
                        //                    use that offset each time it moves
                        
                        var newPoint = touches.first!.location(in: self.view)
                        debugPrint("newPoint =  \(newPoint)")
                        newPoint.x -= offset.x
                        newPoint.y -= offset.y
                        debugPrint("Modified =  \(newPoint)")
                        //movingObject. = touches.first!.location(in: self.view)
                        movingObject.center = newPoint
                    }
                }
                
                
            }

        }
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        //todo: make work
    }
    
    @IBAction func pinch1(_ sender: UIPinchGestureRecognizer) {guard sender.view != nil else { return }
        //print(movingObject?.backgroundColor)
        if sender.state == .began || sender.state == .changed {
            sender.view?.transform = (sender.view?.transform.scaledBy(x: sender.scale, y: sender.scale))!
            sender.scale = 1.0
        }}
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
