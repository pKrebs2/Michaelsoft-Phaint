//
//  UserView.swift
//  Michaelsoft Phaint V9
//
//  Created by Paul V Krebs on 4/22/23.
//

import UIKit

class UserView: UIView {
//    var myRect: CGRect?
    func viewDidLoad() {
        self.backgroundColor = .orange
        
        
//        addGesture()
        
        
        
    
        
        // Do any additional setup after loading the view.
    }
    
//    private func addGesture() {
//        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(pinch(_ :)))
//        
//        self.addGestureRecognizer(pinchGesture)
//    }
//    
//    @objc func pinch(_ sender: UIPinchGestureRecognizer) {
//        print("in")
//        //print(movingObject?.backgroundColor)
//        if sender.state == .began || sender.state == .changed {
//            self.transform = (self.transform.scaledBy(x: sender.scale, y: sender.scale))
//            sender.scale = 1.0
//        }}
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
//    override func draw(_ rect: CGRect) {
//        print("DRAWING")
//        guard let context = UIGraphicsGetCurrentContext() else {return}
//        myRect = rect
////        guard let context = UIGraphicsconte() else {return}
//        draw(inContext: context)
//    }
//
//
//    func draw(inContext context: CGContext){
//        print("userDraw")
//        context.setLineWidth(15)
//        context.setStrokeColor(UIColor.blue.cgColor)
//        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.1, initialSpringVelocity: 0.1, animations: {
//            context.addRect(self.myRect ?? .null)
//
//        }, completion: {_ in
//            UIView.animate(withDuration: 0.3, delay: 0.1, usingSpringWithDamping: 0.4, initialSpringVelocity: 0.2, options: .curveEaseIn, animations: {
//                context.resetClip()
//            })
//        })
////    completion: {_ in
////            UIView.animate(withDuration: 0.3, delay: 0.1, usingSpringWithDamping: 0.4, initialSpringVelocity: 0.2, options: .curveEaseIn, animations: {
////
////            })
//        context.drawPath(using: .stroke)
//
//
//    }
//
   
}
