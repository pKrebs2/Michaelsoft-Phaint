//
//  ViewController.swift
//  Michaelsoft Phaint V9
//
//  Created by Paul V Krebs on 4/21/23.
//

import UIKit
import PhotosUI

class ViewController: UIViewController{

    
    @IBOutlet weak var myTitle: UILabel!
    
    @IBOutlet weak var buttonOutlet: UIButton!
    
    let buttonText = "To editor"
    
    @IBOutlet weak var logo: UIImageView!
    
    
    
    override func viewDidLoad() {
        myTitle.textColor = .magenta
        myTitle.text = "Michaelsoft\nPhaint V9"
        myTitle.font = .italicSystemFont(ofSize: 40.0)
        logo.image = UIImage(named: "brush")
//        buttonOutlet.titleLabel?.text = buttonText
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
    }


}

