//
//  Canvas.swift
//  Michaelsoft Phaint V9
//
//  Created by Paul V Krebs on 4/28/23.
//

import UIKit

class Canvas: UIView {
    public var lineArray: [[CGPoint]] = [[CGPoint]]()
    public var colourArray = [CGColor]()
    public var drawSizeArray = [CGFloat]()
//    var myRect: CGRect?
    
    override func draw(_ rect: CGRect){
        
        guard let context = UIGraphicsGetCurrentContext() else {return}
//        guard let context = UIGraphicsconte() else {return}
        draw(inContext: context)
    }
    
//    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
//        if (!MainViewController.drawMode){
//            return
//        }
//        guard let touch = touches.first else {return}
//        let firstPoint = touch.location(in: self)
//
//        lineArray.append([CGPoint]())
//        lineArray[lineArray.count - 1].append(firstPoint)
//    }
    
//    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
//        if (!MainViewController.drawMode){
//            return
//        }
//        guard let touch = touches.first else {return}
//        let currentPoint = touch.location(in: self
//        )
//        lineArray[lineArray.count - 1].append(currentPoint)
//
//        setNeedsDisplay()
//    }
//    
    func draw(inContext context: CGContext){
//        context.setLineWidth(CGFloat(MainViewController.drawSize * 100))
        
//        context.setStrokeColor(UIColor.blue.cgColor)
        context.setLineCap(.round)
        if MainViewController.drawMode{
            var i = 0;
            for line in lineArray{
                context.setStrokeColor(colourArray[i])
                context.setLineWidth(drawSizeArray[i] + 1)
                i += 1
                guard let firstPoint = line.first else {continue}
                context.beginPath()
                context.move(to: firstPoint)
                
                for point in line.dropFirst(){
                    context.addLine(to: point)
                }
                context.strokePath()
            }
        }
    }
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
