//
//  UserImage.swift
//  Michaelsoft Phaint V9
//
//  Created by Paul V Krebs on 4/22/23.
//

import UIKit

class UserImage: UIImageView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
